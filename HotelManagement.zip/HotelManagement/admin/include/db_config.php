<?php
    define('DB_SERVER','localhost:3307');
    define('DB_USERNAME','root');
    define('DB_PASSWORD','');
    define('DB_DATABASE','hotel');

?>